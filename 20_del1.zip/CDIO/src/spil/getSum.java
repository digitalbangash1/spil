package spil;

public class getSum {
}
